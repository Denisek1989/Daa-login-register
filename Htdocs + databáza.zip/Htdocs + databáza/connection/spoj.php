<?php
$servername = 'localhost';
$username = 'root';
$password = '';
$database = 'login a register';



$spoj = new mysqli($servername, $username, $password, $database);

// Check connection
if ($spoj->connect_error) {
  die("Connection failed: " . $spoj->connect_error);
}
?>