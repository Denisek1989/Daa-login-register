<?php
require_once('../connection/spoj.php');


$meno = $_POST["meno"];
$heslo = $_POST["heslo"];

$sqlMe = "SELECT * FROM `pouzivatelia` WHERE Meno = '$meno'";
$sqlHe = "SELECT * FROM `pouzivatelia` WHERE Heslo = '$heslo'";
$idM = "SELECT Id FROM `pouzivatelia` WHERE Meno = '$meno'";
$idH = "SELECT Id FROM `pouzivatelia` WHERE Heslo = '$heslo'";
$rMe = mysqli_query($spoj, $sqlMe);
$rHe = mysqli_query($spoj, $sqlHe);
$idM = mysqli_query($spoj, $idM);
$idH = mysqli_query($spoj, $idH);
$f1 = mysqli_fetch_assoc($idM);
$f2 = mysqli_fetch_assoc($idH);

if (mysqli_num_rows($rMe) == 1 && mysqli_num_rows($rHe) > 0 && $f1 == $f2) {
    echo "Uspesny login!!";
}
else{
    echo "Zle meno alebo heslo";
}
?>