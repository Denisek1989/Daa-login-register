<?php
require_once('../connection/spoj.php');


$meno =  $_POST["meno"];
$priezvisko =  $_POST["priezvisko"];
$email = $_POST["email"];
$heslo =  $_POST["hesl"];
$prazdny = false;
$dlzkahesl = true;
$rovankehesl = true;
$cislohesl = true;
$meno_emailexist = false;

    if(empty($_POST["email"])){
        $prazdny = true;
    }
    if(empty($_POST["meno"])){
        $prazdny = true;
    }
    if(empty($_POST["priezvisko"])){
        $prazdny = true;
    }
    if(empty($_POST["hesl"])){
        $prazdny = true;
    }
    if(empty($_POST["kontrolahesl"])){
        $prazdny = true;
    }
    if($prazdny == true){
        echo "Upps!! Zabudol si niečo zadať.";
    }
    else{
    }
    
    
    $sqlm = "SELECT * FROM pouzivatelia WHERE Meno ='$meno'";
    $sqle = "SELECT * FROM pouzivatelia WHERE Email ='$email'";
    $r_u = mysqli_query($spoj, $sqlm);
    $r_e = mysqli_query($spoj, $sqle);

    if (mysqli_num_rows($r_u) > 0) {
        $meno_emailexist = true;
        echo "Uzivatelske meno uz existuje" . "<br>";
    }	
    if(mysqli_num_rows($r_e) > 0){
        $meno_emailexist = true;
        echo "Email uz bol pouzity" . "<br>"; 
    }


    if($prazdny == false && $dlzkahesl == true && $cislohesl == true && $rovankehesl == true  && $meno_emailexist == false){
    

            $sql = "INSERT INTO pouzivatelia (Email, Meno, Priezvisko, Heslo) VALUES ('$email', '$meno','$priezvisko','$heslo')";

            if ($spoj->query($sql) === TRUE) {
                header('Location: ../pages/login.php');
            }
            else {
                echo "Niekde je chyba!!" . "<br>";
            }
            
            $spoj->close();
            
        }
        else{
            echo "Niekde je chyba!!" . "<br>"; 

        }

if (!preg_match('@[0-9]@', $heslo)) {
    $cislohesl = false;
    echo "Heslo musi obsahovat aspon jeden ciselny znak" . "<br>";
}
if (($_POST["hesl"]) == ($_POST["kontrolahesl"]))
{
    $rovankehesl = true;
}
else{
    $rovankehesl = false;
    echo "Hesla sa nezhodujú" . "<br>";

}



if(strlen($heslo) < 6){
    $dlzkahesl = false;
    echo "Heslo musi mat minimalne 6 znakov!!!" . "<br>";
} 
else{
    $dlzkahesl = true;
}

  

?>