<?php
require_once('../connection/spoj.php');
?>

<!DOCTYPE html>
<html>
<head>
<title>Login</title>
  <link rel="stylesheet" href="login.css" http-equip="Content-Type" >
</head>
<body>

    
      
        <form method="POST" class="formular" method="POST" action="/scripts/scrip_login.php">
          <h1>Login</h1>
          <label for="meno"><b>Meno</b></label>
          <br>
          <input type="text" placeholder="Zadaj meno" id="meno" name="meno" required>
          <p>
          <label for="hesl"><b>Heslo</b></label>
          <br>
          <input type="heslo" placeholder="Zadaj heslo" id="heslo" name="heslo" required>
          <p>
          <div class = log>
          <button type="submit" id = "log" value="log">Prihlasenie</button>
        </div>
        <div class = registruj>
        <button><a href="register.php">Registrovať sa!</a></button>
        </div>
        </form>
        <p>

       
      

      </form>

    </body>
</html>