
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="style/app.css">

    <title>Domov</title>

</head>
<body>
<?php session_start();?>
    <header>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav">
                    <li class="nav-item">
                    <a class="btn btn-outline-warning" aria-current="page" href="index.php">Domov</a>
                    </li>
                    <?php if (!isset($_SESSION["meno"])): ?>
                    <br
                    <li class="nav-item">
                    <a class="btn btn-outline-primary" aria-current="page" href='../pages/register.php'>Registrovat sa</a>
                    </li>
                    <li class="nav-item">
                    <a class="btn btn-outline-success" aria-current="page" href='../pages/login.php'>Prihlasit sa</a>
                    </li>
                    <?php else : ?>
                        <li class="nav-item">
                            <br>
                            <a class="nav-link active" aria-current="page"><?php echo $_SESSION["meno"]?></a>
                        </li>
                        <li class="nav-item">
                        <a  class="btn btn-outline-danger" aria-current="page" href="logout.php">Odhlasiť sa</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div> 
    </nav>
        
</header>
<main>
<div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="https://images4.alphacoders.com/294/thumbbig-294568.webp" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="https://images8.alphacoders.com/748/thumbbig-748363.webp" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="https://images.alphacoders.com/605/thumbbig-605592.webp" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="https://images2.alphacoders.com/100/thumbbig-1008472.webp" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="https://images3.alphacoders.com/111/thumbbig-1116286.webp" class="d-block w-100" alt="...">
    </div>
</div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
</main>
<footer>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>
</html>