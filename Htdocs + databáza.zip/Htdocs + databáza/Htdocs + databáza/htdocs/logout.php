<?php
session_start();
unset($_SESSION["meno"]);
session_destroy();
header('Location: ../index.php');